#!/bin/sh
# Builds Postfix's whole configuration from .env on every start, so there are
# no config files to hand-edit. Re-running with changed .env values applies
# them; the queue in ./state/spool and the TLS key in ./state/tls persist.
set -eu

fail() { echo "[mail-relay] $*" >&2; exit 1; }
log()  { echo "[mail-relay] $*"; }

: "${RELAY_HOSTNAME:?RELAY_HOSTNAME must be set in .env}"
: "${RELAY_USERNAME:?RELAY_USERNAME must be set in .env}"
: "${RELAY_PASSWORD:?RELAY_PASSWORD must be set in .env}"
: "${RELAY_ALLOWED_SENDER_DOMAINS:?RELAY_ALLOWED_SENDER_DOMAINS must be set in .env}"
RELAY_BIND="${RELAY_BIND:-0.0.0.0}"
RELAY_PORT="${RELAY_PORT:-2465}"
RELAY_ALLOWED_CLIENTS="${RELAY_ALLOWED_CLIENTS:-}"
RELAY_INET_PROTOCOLS="${RELAY_INET_PROTOCOLS:-ipv4}"
RELAY_MESSAGE_SIZE_LIMIT="${RELAY_MESSAGE_SIZE_LIMIT:-52428800}"
RELAY_AUTH_RATE_LIMIT="${RELAY_AUTH_RATE_LIMIT:-20}"

case "$RELAY_PASSWORD" in
  ""|change-me*|ChangeMe*) fail "RELAY_PASSWORD is still the placeholder — set a real one in .env" ;;
esac
case "$RELAY_HOSTNAME" in
  *example.com*) fail "RELAY_HOSTNAME is still the example value — set your mail hostname in .env" ;;
esac
case "$RELAY_PORT" in
  25) fail "RELAY_PORT can't be 25: the Linode nginx stream proxy already owns 25 for inbound mail" ;;
esac

# ---------------------------------------------------------------- TLS ------
# Self-signed is enough here: only Stalwart connects to this port, over your
# WireGuard tunnel, and it logs in with RELAY_USERNAME/RELAY_PASSWORD.
TLS_DIR=/etc/postfix/tls
CERT="$TLS_DIR/relay.crt"; KEY="$TLS_DIR/relay.key"
mkdir -p "$TLS_DIR"
if [ ! -s "$CERT" ] || [ ! -s "$KEY" ]; then
  log "Generating a self-signed certificate for the relay port"
  openssl req -x509 -newkey rsa:2048 -nodes -days 3650 -subj "/CN=$RELAY_HOSTNAME" \
    -keyout "$KEY" -out "$CERT" >/dev/null 2>&1
fi
chmod 600 "$KEY"

# ---------------------------------------------------------------- SASL -----
# One login (RELAY_USERNAME / RELAY_PASSWORD) in a sasldb rebuilt on every
# start, so changing the password in .env is all it takes.
mkdir -p /etc/postfix/sasl
cat > /etc/postfix/sasl/smtpd.conf <<EOF
pwcheck_method: auxprop
auxprop_plugin: sasldb
mech_list: PLAIN LOGIN
sasldb_path: /etc/postfix/sasl/sasldb2
EOF
rm -f /etc/postfix/sasl/sasldb2
printf '%s' "$RELAY_PASSWORD" | saslpasswd2 -p -c -f /etc/postfix/sasl/sasldb2 -u "$RELAY_HOSTNAME" "$RELAY_USERNAME"
chown root:postfix /etc/postfix/sasl/sasldb2
chmod 640 /etc/postfix/sasl/sasldb2

# ---------------------------------------------------------------- maps -----
# Only these sender domains may be relayed (plus the null sender for bounces).
{
  echo '/^<>$/ DUNNO'
  echo "$RELAY_ALLOWED_SENDER_DOMAINS" | tr ', ' '\n\n' | while IFS= read -r d; do
    [ -n "$d" ] || continue
    esc=$(printf '%s' "$d" | sed 's/[.[\*^$()+?{|]/\\&/g')
    echo "/@(.+\\.)?${esc}\$/ DUNNO"
  done
  echo '/./ REJECT This relay only sends mail for its own domains'
} > /etc/postfix/sender_access

CLIENT_RESTRICTIONS="permit"
if [ -n "$RELAY_ALLOWED_CLIENTS" ]; then
  : > /etc/postfix/allowed_clients
  echo "$RELAY_ALLOWED_CLIENTS" | tr ', ' '\n\n' | while IFS= read -r c; do
    [ -n "$c" ] && echo "$c OK" >> /etc/postfix/allowed_clients
  done
  CLIENT_RESTRICTIONS="check_client_access cidr:/etc/postfix/allowed_clients, reject"
fi

# ---------------------------------------------------------------- main.cf --
# Fresh from the stock file every start, so a setting removed from .env
# doesn't linger.
cp /etc/postfix/main.cf.stock /etc/postfix/main.cf
postconf -e \
  "compatibility_level = 3.6" \
  "myhostname = $RELAY_HOSTNAME" \
  "myorigin = \$myhostname" \
  "mydestination =" \
  "local_recipient_maps =" \
  "local_transport = error:5.1.1 This host doesn't accept local mail" \
  "relay_domains =" \
  "mynetworks = 127.0.0.0/8" \
  "inet_interfaces = all" \
  "inet_protocols = $RELAY_INET_PROTOCOLS" \
  "smtp_address_preference = ipv4" \
  "maillog_file = /dev/stdout" \
  "smtp_helo_name = \$myhostname" \
  "smtpd_banner = \$myhostname ESMTP" \
  "disable_vrfy_command = yes" \
  "message_size_limit = $RELAY_MESSAGE_SIZE_LIMIT" \
  "smtpd_tls_cert_file = $CERT" \
  "smtpd_tls_key_file = $KEY" \
  "smtpd_tls_security_level = encrypt" \
  "smtpd_tls_auth_only = yes" \
  "smtpd_tls_received_header = yes" \
  "smtpd_tls_mandatory_protocols = >=TLSv1.2" \
  "smtp_tls_security_level = may" \
  "smtp_tls_CAfile = /etc/ssl/certs/ca-certificates.crt" \
  "smtp_tls_loglevel = 1" \
  "smtpd_sasl_auth_enable = yes" \
  "smtpd_sasl_type = cyrus" \
  "smtpd_sasl_path = smtpd" \
  "cyrus_sasl_config_path = /etc/postfix/sasl" \
  "smtpd_sasl_local_domain = \$myhostname" \
  "smtpd_sasl_security_options = noanonymous" \
  "broken_sasl_auth_clients = no" \
  "smtpd_client_restrictions = $CLIENT_RESTRICTIONS" \
  "smtpd_sender_restrictions = check_sender_access regexp:/etc/postfix/sender_access" \
  "smtpd_relay_restrictions = permit_sasl_authenticated, reject" \
  "smtpd_recipient_restrictions = permit_sasl_authenticated, reject" \
  "smtpd_client_auth_rate_limit = $RELAY_AUTH_RATE_LIMIT" \
  "anvil_rate_time_unit = 60s" \
  "smtpd_hard_error_limit = 5" \
  "alias_maps =" \
  "alias_database ="

# ---------------------------------------------------------------- master.cf
# Start from the stock file each time, drop the default port-25 listener
# (nginx on this host owns 25), and add the relay listener: implicit TLS,
# SASL required, not chrooted so it can read the sasldb.
cp /etc/postfix/master.cf.stock /etc/postfix/master.cf
postconf -M# smtp/inet 2>/dev/null || true
postconf -M "${RELAY_BIND}:${RELAY_PORT}/inet=${RELAY_BIND}:${RELAY_PORT} inet n - n - - smtpd"
postconf -P "${RELAY_BIND}:${RELAY_PORT}/inet/smtpd_tls_wrappermode=yes"
postconf -M "postlog/unix-dgram=postlog unix-dgram n - n - 1 postlogd"

# ---------------------------------------------------------------- start ----
postfix post-install create-missing >/dev/null 2>&1 || true
postfix set-permissions >/dev/null 2>&1 || true
postfix check
log "Relaying for: $RELAY_ALLOWED_SENDER_DOMAINS  |  listening on ${RELAY_BIND}:${RELAY_PORT} (implicit TLS, SASL user ${RELAY_USERNAME})"
[ -n "$RELAY_ALLOWED_CLIENTS" ] && log "Only accepting connections from: $RELAY_ALLOWED_CLIENTS"
exec postfix start-fg
