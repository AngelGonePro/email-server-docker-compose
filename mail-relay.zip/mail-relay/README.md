# mail-relay

Send-only Postfix relay for the Linode. The home `stalwart-mail` stack hands
it outgoing mail over your StratumVPN WireGuard tunnel, and it delivers that
mail from the Linode's own IP, the one with the matching reverse DNS. It
delivers nothing locally and doesn't touch port 25 inbound: nginx keeps 25 for
incoming mail via frp.

- One listener on `RELAY_BIND:RELAY_PORT` (default `0.0.0.0:2465`). It uses
  implicit TLS, a self-signed certificate made on first start, and requires a
  login (`RELAY_USERNAME` / `RELAY_PASSWORD`). There's no unauthenticated
  relaying.
- It only sends for `RELAY_ALLOWED_SENDER_DOMAINS` (plus bounces), even with a
  valid login.
- Optional source allowlist (`RELAY_ALLOWED_CLIENTS`), and login-attempt rate
  limiting per IP.
- Host networking, so there's no Docker NAT and no firewall rules on a host
  whose firewall is already managed by SoftEther/WireGuard/Tailscale.
- The whole Postfix config is generated from `.env` on every start. The mail
  queue (`state/spool`) and the TLS key (`state/tls`) persist.

## Install / update (same command for both)

```bash
curl -fsSL -o /tmp/mail-relay.zip https://github.com/AngelGonePro/stalwart-mail/raw/refs/heads/main/mail-relay.zip && python3 -c "import zipfile;open('/tmp/mail-relay-deploy.sh','wb').write(zipfile.ZipFile('/tmp/mail-relay.zip').read('mail-relay/deploy-update.sh'))" && bash /tmp/mail-relay-deploy.sh /tmp/mail-relay.zip ~/mail-relay
```

The first run puts the project in `~/mail-relay`, lists the `.env` values
still to set, and stops. Set them and run the command again to build and start
it. Later runs upgrade in place: `.env` and `state/` are never overwritten,
and files you edited are left alone and reported.

## Linode prerequisites (once)

1. **Reverse DNS:** in Cloud Manager open the Linode → Network → IPv4 address
   → Edit RDNS, and set it to `RELAY_HOSTNAME` (e.g. `mail.example.com`). The
   name's A record must already point to this Linode.
2. **SMTP unblock:** new Linode accounts block outbound 25/465/587. Open a
   Support ticket asking to lift the SMTP restriction for this Linode,
   confirming the rDNS is set and that your mail is CAN-SPAM compliant.
3. **If this Linode also runs wg-vpn-gateway** (standalone mode), add `25` to
   its `BYPASS_OUT_TCP_PORTS` (e.g. `22,25`), so delivery leaves from this IP
   and not the VPN's. Connections arriving from home already reply directly.

## Checking it

```bash
cd ~/mail-relay
docker compose logs -f            # each message: client, sasl_username, delivery status
docker exec mail-relay postqueue -p   # anything waiting/deferred
docker exec mail-relay postqueue -f   # retry the queue now
```

Once mail flows, the log shows which address your home traffic arrives from
(`connect from ...[x.x.x.x]`). Put that in `RELAY_ALLOWED_CLIENTS` to refuse
everyone else outright.
