#!/bin/sh
# Writes frpc.toml from .env and starts frpc. Each enabled mail port becomes
# one TCP proxy named <FRP_PROXY_PREFIX>-<service>-<public port>-realip, which
# is the naming ratelimit-gen on the Linode needs to auto-create the public
# nginx listener (with "proxy_protocol on", so Stalwart sees real client IPs).
#
# transport.proxyProtocolVersion is deliberately NOT set: nginx on the Linode
# already adds the PROXY header and frp passes it through untouched; a second
# header from frp would corrupt the first.
set -eu

fail() { echo "[frpc] $*" >&2; exit 1; }

: "${FRP_SERVER_ADDR:?FRP_SERVER_ADDR must be set in .env}"
: "${FRP_TOKEN:?FRP_TOKEN must be set in .env}"
FRP_SERVER_PORT="${FRP_SERVER_PORT:-7000}"
FRP_PROXY_PREFIX="${FRP_PROXY_PREFIX:-mail}"
STALWART_HOST="${STALWART_HOST:-stalwart}"

case "$FRP_TOKEN" in change-me*|"") fail "FRP_TOKEN is still the placeholder — use the same token as your other frpc/frps" ;; esac

toml_str() { printf '%s' "$1" | sed -e 's/\\/\\\\/g' -e 's/"/\\"/g'; }

OUT=/tmp/frpc.toml
{
  printf 'serverAddr = "%s"\n' "$(toml_str "$FRP_SERVER_ADDR")"
  echo "serverPort = $FRP_SERVER_PORT"
  echo "loginFailExit = false"
  echo ""
  echo "auth.method = \"token\""
  printf 'auth.token = "%s"\n' "$(toml_str "$FRP_TOKEN")"
  echo ""
  echo "transport.tls.enable = true"
  echo ""
  echo "log.to = \"console\""
  echo "log.level = \"${FRP_LOG_LEVEL:-info}\""
} > "$OUT"

COUNT=0
# service | public port | frps-side internal port (from .env) | Stalwart tunnel listener port
add_proxy() {
  svc=$1; public=$2; remote=$3; local=$4
  [ -n "$remote" ] || return 0
  [ "$remote" = "$public" ] && fail "FRP_$(echo "$svc" | tr a-z A-Z)_REMOTE_PORT must differ from the public port $public (nginx binds the public one)"
  cat >> "$OUT" <<EOF

[[proxies]]
name = "${FRP_PROXY_PREFIX}-${svc}-${public}-realip"
type = "tcp"
localIP = "$STALWART_HOST"
localPort = $local
remotePort = $remote
EOF
  echo "[frpc] public ${public} -> frps 127.0.0.1:${remote} -> ${STALWART_HOST}:${local} (${svc})" >&2
  COUNT=$((COUNT + 1))
}

add_proxy smtp        25  "${FRP_SMTP_REMOTE_PORT:-}"        "${TUNNEL_SMTP_PORT:-10025}"
add_proxy submissions 465 "${FRP_SUBMISSIONS_REMOTE_PORT:-}" "${TUNNEL_SUBMISSIONS_PORT:-10465}"
add_proxy submission  587 "${FRP_SUBMISSION_REMOTE_PORT:-}"  "${TUNNEL_SUBMISSION_PORT:-10587}"
add_proxy imaps       993 "${FRP_IMAPS_REMOTE_PORT:-}"       "${TUNNEL_IMAPS_PORT:-10993}"
add_proxy sieve       4190 "${FRP_SIEVE_REMOTE_PORT:-}"      "${TUNNEL_SIEVE_PORT:-14190}"

[ "$COUNT" -gt 0 ] || fail "No ports enabled — set at least FRP_SMTP_REMOTE_PORT in .env"

exec frpc -c "$OUT"
