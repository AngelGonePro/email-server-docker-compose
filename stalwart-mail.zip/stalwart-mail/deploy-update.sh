#!/usr/bin/env bash
# Usage: deploy-update.sh <zip-url-or-path> [target-dir]      (target defaults to ~/stalwart-mail)
#
# Installs stalwart-mail on a home VM, or upgrades an existing install, from a release zip.
# Same rules as your other stacks' deploy-update.sh:
#   * .env and data/ (mailboxes, accounts, settings) are never overwritten
#   * any other file you hand-edited since the last update is left alone and reported
#     (detected against a baseline snapshot of what was last applied)
#   * new .env keys from the template are appended with their defaults; your values stay
#   * nothing is deleted automatically — removed files are only reported
# Then, once .env has real values, it (re)starts the stack, lets the setup step apply .env
# to Stalwart (restarting Stalwart once when a change needs it) and checks everything is up.
set -euo pipefail

# Run from a private copy so this script can safely replace its own installed file.
if [[ -z ${STALWARTMAIL_DEPLOY_COPY:-} ]]; then
  self_copy=$(mktemp)
  cp "$0" "$self_copy"
  STALWARTMAIL_DEPLOY_COPY=$self_copy exec bash "$self_copy" "$@"
fi
trap 'rm -f "$STALWARTMAIL_DEPLOY_COPY"' EXIT

PROJECT=stalwart-mail
HEALTH_TIMEOUT=${HEALTH_TIMEOUT:-180}
RESTART_NEEDED=75

for cmd in curl python3 docker; do
  if ! command -v "$cmd" >/dev/null 2>&1; then
    echo "Missing dependency: $cmd" >&2
    [[ $cmd == docker ]] && echo "Install Docker Engine + the compose plugin first." >&2 \
                         || echo "Install it first: sudo apt update && sudo apt install -y $cmd" >&2
    exit 1
  fi
done
docker compose version >/dev/null 2>&1 || { echo "The docker compose plugin is missing." >&2; exit 1; }

SOURCE="${1:?Usage: $0 <zip-url-or-path> [target-dir]}"
TARGET_DIR="${2:-$HOME/$PROJECT}"

if [[ $(basename "$PWD") == "$TARGET_DIR" ]] && { [[ -f docker-compose.yml ]] || [[ -f .env ]]; }; then
  echo "You're already inside '$TARGET_DIR' with an existing deployment — using '.' instead of nesting." >&2
  TARGET_DIR="."
fi

HARD_PROTECTED_PATHS="
.env
.deploy-baseline
data
"
BASELINE_DIR="$TARGET_DIR/.deploy-baseline"

is_hard_protected() {
  local path=$1 p
  for p in $HARD_PROTECTED_PATHS; do
    case "$path" in "$p"|"$p"/*) return 0 ;; esac
  done
  return 1
}

WORK=$(mktemp -d)
trap 'rm -f "$STALWARTMAIL_DEPLOY_COPY"; rm -rf "$WORK"' EXIT
TMP_ZIP="$WORK/release.zip"
TMP_EXTRACT="$WORK/extract"
mkdir -p "$TMP_EXTRACT"

if [[ $SOURCE =~ ^(https?|file):// ]]; then
  echo "==> Downloading $SOURCE"
  curl -fsSL -o "$TMP_ZIP" "$SOURCE"
else
  [[ -f $SOURCE ]] || { echo "Zip not found: $SOURCE" >&2; exit 1; }
  cp "$SOURCE" "$TMP_ZIP"
fi

echo "==> Extracting (stripping the top-level folder)"
python3 -I - "$TMP_ZIP" "$TMP_EXTRACT" << 'PYEOF'
import zipfile, os, sys
zip_path, extract_to = sys.argv[1], os.path.realpath(sys.argv[2])
with zipfile.ZipFile(zip_path) as z:
    for info in z.infolist():
        parts = info.filename.split("/", 1)
        if len(parts) < 2 or not parts[1] or info.filename.endswith("/"):
            continue
        target = os.path.realpath(os.path.join(extract_to, parts[1]))
        if not target.startswith(extract_to + os.sep):
            sys.exit(f"refusing unsafe path in zip: {info.filename}")
        os.makedirs(os.path.dirname(target), exist_ok=True)
        with open(target, "wb") as f:
            f.write(z.read(info))
        mode = (info.external_attr >> 16) & 0o777
        if mode:
            os.chmod(target, mode)
PYEOF
[[ -f $TMP_EXTRACT/docker-compose.yml && -f $TMP_EXTRACT/setup/setup.py ]] || {
  echo "This zip doesn't look like a $PROJECT release." >&2; exit 1; }

mkdir -p "$TARGET_DIR" "$BASELINE_DIR"

env_value() { # key file
  [[ -f $2 ]] || return 0
  { grep -E "^$1=" "$2" || true; } | tail -n1 | cut -d= -f2- | sed -e 's/^["'\'']//' -e 's/["'\'']$//'
}

echo "==> Applying updates"
NEW_LIST="$WORK/new" EDITED_LIST="$WORK/edited" UNTRACKED_LIST="$WORK/untracked" UPDATED_LIST="$WORK/updated"
: > "$NEW_LIST"; : > "$EDITED_LIST"; : > "$UNTRACKED_LIST"; : > "$UPDATED_LIST"
while IFS= read -r relpath; do
  is_hard_protected "$relpath" && continue
  target_file="$TARGET_DIR/$relpath"
  baseline_file="$BASELINE_DIR/$relpath"
  new_file="$TMP_EXTRACT/$relpath"

  if [[ ! -e $target_file ]]; then
    mkdir -p "$(dirname "$target_file")"
    cp -p "$new_file" "$target_file"
    echo "$relpath" >> "$NEW_LIST"
  elif [[ -f $baseline_file ]] && cmp -s "$target_file" "$baseline_file"; then
    # untouched since the last update — safe to replace
    if ! cmp -s "$new_file" "$target_file"; then
      cp -p "$new_file" "$target_file"
      echo "$relpath" >> "$UPDATED_LIST"
    fi
  elif [[ -f $baseline_file ]]; then
    # you edited it since the last update — leave it
    cmp -s "$new_file" "$target_file" || echo "$relpath" >> "$EDITED_LIST"
  else
    # pre-existing file with no baseline yet — leave it this once
    cmp -s "$new_file" "$target_file" || echo "$relpath" >> "$UNTRACKED_LIST"
  fi
  mkdir -p "$(dirname "$baseline_file")"
  cp -p "$new_file" "$baseline_file"
done < <(cd "$TMP_EXTRACT" && find . -type f | sed 's#^\./##' | sort)

if [[ -s $NEW_LIST ]]; then echo "    New files added:"; sed 's/^/      /' "$NEW_LIST"; fi
if [[ -s $UPDATED_LIST ]]; then echo "    Updated:"; sed 's/^/      /' "$UPDATED_LIST"; fi
if [[ -s $EDITED_LIST ]]; then
  echo "    Hand-edited by you since the last update — left untouched. To see the new version:"
  while IFS= read -r f; do echo "      diff $TARGET_DIR/$f $BASELINE_DIR/$f"; done < "$EDITED_LIST"
fi
if [[ -s $UNTRACKED_LIST ]]; then
  echo "    First time comparing these against a template — left alone this once; tracked from now on:"
  sed 's/^/      /' "$UNTRACKED_LIST"
fi
[[ -s $NEW_LIST || -s $UPDATED_LIST || -s $EDITED_LIST || -s $UNTRACKED_LIST ]] || echo "    Already up to date."

echo "==> Checking for files this update removed (reported only, nothing deleted)"
ORPHANS=$(cd "$TARGET_DIR" && find . -path ./.deploy-baseline -prune -o -path ./data -prune -o -type f -print | sed 's#^\./##' | sort | while IFS= read -r f; do
  is_hard_protected "$f" && continue
  [[ -e $BASELINE_DIR/$f && ! -e $TMP_EXTRACT/$f ]] && echo "$f"
done || true)
if [[ -n $ORPHANS ]]; then
  echo "    No longer part of the project — safe to remove:"
  sed "s#^#      rm $TARGET_DIR/#" <<<"$ORPHANS"
  while IFS= read -r f; do rm -f "$BASELINE_DIR/$f"; done <<<"$ORPHANS"
else
  echo "    Nothing orphaned."
fi

echo "==> Merging .env"
if [[ -f $TARGET_DIR/.env && -f $TMP_EXTRACT/.env ]]; then
  NEW_KEYS=""
  while IFS= read -r line || [[ -n $line ]]; do
    case "$line" in \#*|"") continue ;; esac
    key=${line%%=*}
    grep -q "^${key}=" "$TARGET_DIR/.env" || NEW_KEYS+="$line"$'\n'
  done < "$TMP_EXTRACT/.env"
  if [[ -n $NEW_KEYS ]]; then
    { echo ""; echo "# --- New in this update ($(date -u +'%Y-%m-%dT%H:%M:%SZ')) — review these ---"
      printf '%s' "$NEW_KEYS"; } >> "$TARGET_DIR/.env"
    echo "    New .env keys added with their defaults (bottom of $TARGET_DIR/.env):"
    printf '%s' "$NEW_KEYS" | sed 's/^/      /'
  else
    echo "    No new .env keys."
  fi
  echo "    All your existing values were left exactly as they were."
  OBSOLETE=""
  while IFS= read -r line || [[ -n $line ]]; do
    case "$line" in \#*|"") continue ;; esac
    key=${line%%=*}
    grep -q "^${key}=" "$TMP_EXTRACT/.env" || OBSOLETE+="$key"$'\n'
  done < "$TARGET_DIR/.env"
  if [[ -n $OBSOLETE ]]; then
    echo "    No longer used by the template (left in place):"
    printf '%s' "$OBSOLETE" | sed 's/^/      /'
  fi
elif [[ -f $TMP_EXTRACT/.env ]]; then
  cp "$TMP_EXTRACT/.env" "$TARGET_DIR/.env"
  chmod 600 "$TARGET_DIR/.env"
  echo "    No existing .env — copied the template."
fi

# ---------------------------------------------------------------- start / restart ---
ENV_FILE="$TARGET_DIR/.env"
missing=()
for key in MAIL_DOMAIN MAIL_HOSTNAME; do
  v=$(env_value $key "$ENV_FILE"); [[ -z $v || $v == *example.com* ]] && missing+=("$key")
done
for key in ADMIN_PASSWORD FRP_TOKEN; do
  v=$(env_value $key "$ENV_FILE"); [[ -z $v || $v == change-me* ]] && missing+=("$key")
done
if [[ $(env_value RELAY_ENABLED "$ENV_FILE") != false ]]; then
  v=$(env_value RELAY_PASSWORD "$ENV_FILE"); [[ -z $v || $v == change-me* ]] && missing+=("RELAY_PASSWORD")
fi

echo ""
if (( ${#missing[@]} )); then
  echo "==> Files are in place, but these .env values still need setting, so nothing was started:"
  printf '      %s\n' "${missing[@]}"
  echo "    Edit $ENV_FILE, then run the same install/update command again."
  exit 0
fi

cd "$TARGET_DIR"
chmod 600 .env
mkdir -p data

# Runs the setup container and returns its exit code.
run_setup() {
  local cid code
  docker compose up -d --no-deps --force-recreate setup >/dev/null 2>&1
  cid=$(docker compose ps -aq setup)
  code=$(docker wait "$cid")
  docker logs "$cid" 2>&1 | sed 's/^/    /'
  return "$code"
}

echo "==> Building / starting the stack"
docker compose up -d --build --remove-orphans

echo "==> Applying .env to Stalwart"
set +e
cid=$(docker compose ps -aq setup)
code=$(docker wait "$cid"); docker logs "$cid" 2>&1 | sed 's/^/    /'
for _ in 1 2; do
  [[ $code == "$RESTART_NEEDED" ]] || break
  echo "==> Restarting Stalwart to apply that"
  docker compose restart stalwart >/dev/null
  run_setup; code=$?
done
set -e
if [[ $code != 0 ]]; then
  echo "    The setup step failed (exit $code) — see the messages above." >&2
  echo "    Fix .env and run the install/update command again. Stalwart logs:  docker compose logs stalwart" >&2
  exit 1
fi

echo "==> Waiting up to ${HEALTH_TIMEOUT}s for Stalwart and the frp tunnel"
deadline=$(( $(date +%s) + HEALTH_TIMEOUT ))
st=unknown fr=unknown
while (( $(date +%s) < deadline )); do
  st=$(docker inspect -f '{{if .State.Health}}{{.State.Health.Status}}{{else}}{{.State.Status}}{{end}}' "$(docker compose ps -aq stalwart)" 2>/dev/null || echo unknown)
  fcid=$(docker compose ps -aq frpc)
  fr=$(docker inspect -f '{{if .State.Restarting}}restarting{{else}}{{.State.Status}}{{end}}' "$fcid" 2>/dev/null || echo unknown)
  if [[ $fr == running ]]; then
    flog=$(docker logs --since "$(docker inspect -f '{{.State.StartedAt}}' "$fcid")" "$fcid" 2>&1 || true)
    if grep -q "start error" <<<"$flog"; then fr="proxy refused by frps"; break; fi
    grep -q "login to server success" <<<"$flog" || fr="not connected to frps yet"
  fi
  [[ $st == healthy && $fr == running ]] && break
  [[ $fr == restarting ]] && break
  sleep 3
done
if [[ $st != healthy || $fr != running ]]; then
  echo "    Not healthy yet: stalwart=$st frpc=$fr" >&2
  [[ $fr == "not connected to frps yet" ]] && echo "    Check FRP_SERVER_ADDR / FRP_SERVER_PORT / FRP_TOKEN, and that the Linode IP is in the gateway's SPLIT_TUNNEL_DESTINATIONS." >&2
  [[ $fr == "proxy refused by frps" ]] && echo "    An FRP_*_REMOTE_PORT is already used by another frp proxy — pick a free one." >&2
  echo "---- last log lines ----" >&2
  docker compose logs --tail 25 stalwart frpc >&2 || true
  echo "------------------------" >&2
  exit 1
fi

HTTP_PORT_VALUE=$(env_value HTTP_PORT .env)
echo ""
echo "==> Done. Stalwart is running and the frp tunnel is connected."
echo "    WebUI:  http://<this VM's IP>:${HTTP_PORT_VALUE:-8080}/admin   (login: ADMIN_USER / ADMIN_PASSWORD from .env)"
echo "    Logs:   cd $(pwd) && docker compose logs -f stalwart frpc"
