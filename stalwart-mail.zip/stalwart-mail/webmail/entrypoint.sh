#!/bin/sh
# Writes Roundcube's config from .env on every start, creates/updates its
# database (./data/webmail), then runs Apache.
set -eu
: "${STALWART_HOST:?}" "${MAIL_DOMAIN:?}"
DATA=/var/lib/roundcube
mkdir -p "$DATA"
[ -s "$DATA/des_key" ] || head -c 64 /dev/urandom | base64 | tr -dc 'A-Za-z0-9' | head -c 24 > "$DATA/des_key"
php_str() { printf '%s' "$1" | sed "s/\\\\/\\\\\\\\/g; s/'/\\\\'/g"; }
cat > /var/www/roundcube/config/config.inc.php <<PHP
<?php
\$config = [];
\$config['db_dsnw'] = 'sqlite:///$DATA/roundcube.db?mode=0640';
\$config['imap_host'] = 'ssl://$STALWART_HOST:993';
\$config['smtp_host'] = 'ssl://$STALWART_HOST:465';
\$config['smtp_user'] = '%u';
\$config['smtp_pass'] = '%p';
\$tls = ['ssl' => ['verify_peer' => false, 'verify_peer_name' => false]];
\$config['imap_conn_options'] = \$tls;
\$config['smtp_conn_options'] = \$tls;
\$config['managesieve_host'] = 'tls://$STALWART_HOST';
\$config['managesieve_port'] = 4190;
\$config['managesieve_conn_options'] = \$tls;
\$config['username_domain'] = '$(php_str "$MAIL_DOMAIN")';
\$config['mail_domain'] = '$(php_str "$MAIL_DOMAIN")';
\$config['product_name'] = '$(php_str "${WEBMAIL_TITLE:-Webmail}")';
\$config['des_key'] = '$(cat "$DATA/des_key")';
\$config['plugins'] = ['archive', 'zipdownload', 'managesieve'];
\$config['skin'] = 'elastic';
\$config['log_driver'] = 'stdout';
\$config['enable_installer'] = false;
\$config['max_message_size'] = '${WEBMAIL_UPLOAD_LIMIT:-25M}';
PHP
chown -R www-data:www-data "$DATA"
cd /var/www/roundcube
# Roundcube's SQLite driver creates the database and its tables by itself on
# first connect; updatedb.sh connects (creating it if new) and applies any
# schema changes after a Roundcube version bump.
su -s /bin/sh www-data -c 'bin/updatedb.sh --package=roundcube --dir=SQL'
PHPV=$(ls /etc/php)
for f in "/etc/php/$PHPV/apache2/php.ini"; do
  sed -i "s/^upload_max_filesize.*/upload_max_filesize = ${WEBMAIL_UPLOAD_LIMIT:-25M}/; s/^post_max_size.*/post_max_size = ${WEBMAIL_UPLOAD_LIMIT:-25M}/" "$f"
done
exec apache2ctl -D FOREGROUND
