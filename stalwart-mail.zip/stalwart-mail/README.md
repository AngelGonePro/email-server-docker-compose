# stalwart-mail

[Stalwart](https://stalw.art) mail server for a home VM that sits behind
wg-vpn-gateway. Mail comes **in** through your existing frps/nginx on the
Linode, and goes **out** through the `mail-relay` stack on the Linode, so every
mail server you talk to only ever sees the Linode's IP. Windscribe and your
home IP are never used for mail.

```
Internet ──25/465/587/993──▶ Linode nginx (PROXY protocol, rate limit)
                              └─ frps ◀══ frp tunnel ══ frpc ─▶ Stalwart   (home VM)
Stalwart ── outgoing mail ──▶ wg-vpn-gateway split tunnel (StratumVPN WireGuard)
                              └─ mail-relay on the Linode ─▶ recipients' servers
```

| Container | What it does |
|---|---|
| `stalwart` | The mail server: SMTP, IMAP, JMAP, Sieve, spam filter, DKIM, WebUI. Data in `./data`. |
| `stalwart-frpc` | Its own frpc. One proxy per public port, named `mail-<service>-<port>-realip`, so `ratelimit-gen` on the Linode creates the public nginx listener with `proxy_protocol on` automatically. |
| `setup` | Runs on every start and applies `.env` to Stalwart through its admin API: first-time setup, the tunnel listeners, LAN port 587, the relay route and the log level. Exits when done. |
| `prepare` | Runs on every start and gives `./data` to Stalwart's user (uid 2000). |

Everything you'd change is in `.env`; there are no config files to edit.

## Install / update (same command for both)

```bash
curl -fsSL -o /tmp/stalwart-mail.zip https://github.com/AngelGonePro/stalwart-mail/raw/refs/heads/main/stalwart-mail.zip && python3 -c "import zipfile;open('/tmp/stalwart-mail-deploy.sh','wb').write(zipfile.ZipFile('/tmp/stalwart-mail.zip').read('stalwart-mail/deploy-update.sh'))" && bash /tmp/stalwart-mail-deploy.sh /tmp/stalwart-mail.zip ~/stalwart-mail
```

The first run puts the project in `~/stalwart-mail`, lists the `.env` values
still to fill in, and stops. Fill them in and run the same command again to
start it. Every later run upgrades in place:

- `.env` and `data/` are never overwritten.
- Files you edited are left alone and reported.
- New `.env` keys are added with their defaults.
- The setup step re-applies `.env`, and Stalwart is restarted only when a change
  needs it (first-time setup, or a listener added/removed).

Changed something in `.env`? Run the install command again (or
`docker compose up -d`, which also re-runs the setup step; if it says a restart
is needed, `docker compose restart stalwart && docker compose up setup`).

## Before you start

Install **mail-relay on the Linode first** (its README covers rDNS and the
Linode SMTP unblock), then on the home side:

1. **This VM is a wg-vpn-gateway client**, and the Linode IP (`RELAY_HOST`,
   `FRP_SERVER_ADDR`) is in the gateway's `SPLIT_TUNNEL_DESTINATIONS`
   (`45.79.25.46` already is). That's what keeps both the frp tunnel and the
   outgoing mail on your StratumVPN tunnel instead of Windscribe.
2. **CPU type.** Stalwart's images need an x86-64-v2 CPU. If this Proxmox VM
   uses a generic CPU type (kvm64 / "Common KVM processor"), set it to `host`
   or `x86-64-v2-AES`, or use `STALWART_VERSION=v1.0.3-alpine`.
3. **Linode nginx stack (`linode-nginx-stack/.env`):** add `25` to
   `RATE_LIMIT_EXCLUDE_PORTS`. Big senders (Gmail, Outlook) open several
   connections at once from one IP and the default limit of 3 would make them
   back off. Stalwart has its own per-IP throttling for port 25.
4. **Nothing else listens on 25/465/587/993 on the Linode**
   (`ss -ltnp | grep -E ':(25|465|587|993) '` should be empty).

## DNS (Cloudflare — all records DNS-only / grey cloud)

| Record | Value |
|---|---|
| `A  mail.example.com` | `45.79.25.46` (the Linode) |
| `MX example.com` | `mail.example.com` (priority 10) |
| Linode reverse DNS of `45.79.25.46` | `mail.example.com` |

With `CLOUDFLARE_API_TOKEN` set (Zone → DNS → Edit for the zone), Stalwart
publishes the rest itself: DKIM, SPF (`v=spf1 mx -all`), DMARC, MTA-STS,
TLS-RPT, SRV and autoconfig records, and gets a Let's Encrypt certificate for
`MAIL_HOSTNAME` via DNS-01. That's the only ACME method that works from behind
the tunnel. Without a token, the WebUI lists the records to add by hand, and
the certificate is set up in the WebUI.

MTA-STS and autoconfig are served over HTTPS by Stalwart. Point
`mta-sts.example.com` and `autoconfig.example.com` (and `mail.example.com` for
the WebUI) at this VM's `HTTP_PORT` in your reverse proxy. Use your usual
pattern there: port 80 for the Cloudflare tunnel, 443 for local.

## After it's running

- WebUI: `http://<this VM>:18080/admin` (`HTTP_PORT`), logged in with `ADMIN_USER` /
  `ADMIN_PASSWORD`. Create your mail accounts there.
- Mail apps on the LAN: IMAP `993` (SSL), SMTP `465` (SSL) or `587` (STARTTLS)
  on this VM's IP. From outside: the same ports on `mail.example.com`.
- Logs: `docker compose logs -f stalwart frpc`. They're capped at 2×1 MB per
  container, and `LOG_LEVEL` sets the detail.
- Backups: stop the stack and copy `./data`. That holds everything: mail,
  accounts, settings and DKIM keys.

## What the setup step owns

The setup step manages these and resets them to `.env` on its next run if
they're changed in the WebUI. Change them in `.env` instead:

- the listeners named `submission` (587) and `tunnel-*` (frp only; PROXY
  protocol accepted from `FRPC_IP` alone, so a spoofed PROXY header from
  anything else is ignored)
- the `linode-relay` delivery route and the outgoing **route** rule
  (your own domains are delivered locally, everything else goes to the relay)
- the log level of the console logger

Everything else (accounts, domains, spam filter, quotas, Sieve) is yours to
manage in the WebUI.

## Notes

- `RELAY_ENABLED=false` makes Stalwart deliver straight to recipients' MX
  servers. Behind the gateway that means through Windscribe, which most
  providers reject. Only use it on a host whose own IP has reverse DNS and
  port 25.
- The relay password is never stored in Stalwart's database: Stalwart reads it
  from `STALWART_RELAY_PASSWORD`, which compose fills from `RELAY_PASSWORD`.
  The Cloudflare token works the same way.
- `ADMIN_USER`/`ADMIN_PASSWORD` is a permanent fallback administrator that
  works even if the account database is broken. Keep the password long and
  `.env` private (the deploy script sets it to `chmod 600`).
