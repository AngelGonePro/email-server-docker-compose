#!/usr/bin/env python3
"""Applies .env to Stalwart through its JMAP admin API. Runs on every start.

1. First start (no config yet): completes Stalwart's initial setup with
   MAIL_DOMAIN / MAIL_HOSTNAME (RocksDB, internal accounts, DKIM keys, logs to
   stdout, and Cloudflare DNS + Let's Encrypt via DNS-01 if a token is set).
2. Every start: makes sure the frp tunnel listeners (PROXY protocol accepted
   only from FRPC_IP), the LAN submission port 587, outgoing delivery through
   the Linode relay and the log level match .env.

Exit codes: 0 = everything matches .env, 75 = Stalwart must be restarted to
pick up the change (deploy-update.sh does that and runs this again),
anything else = error (details printed).
"""
import base64
import json
import os
import sys
import time
import urllib.error
import urllib.request

RESTART_NEEDED = 75
USING = ["urn:ietf:params:jmap:core", "urn:stalwart:jmap"]
TUNNEL_PREFIX = "tunnel-"
RELAY_ROUTE = "linode-relay"


def env(key, default=""):
    return os.environ.get(key, default).strip()


def env_bool(key, default="false"):
    return env(key, default).lower() in ("1", "true", "yes", "on")


def log(msg):
    print(f"[setup] {msg}", flush=True)


def die(msg):
    print(f"[setup] ERROR: {msg}", file=sys.stderr, flush=True)
    sys.exit(1)


BASE = env("STALWART_URL", "http://stalwart:8080").rstrip("/")
AUTH = "Basic " + base64.b64encode(f"{env('ADMIN_USER', 'admin')}:{env('ADMIN_PASSWORD')}".encode()).decode()


def http(method, path, body=None, timeout=60):
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(BASE + path, data=data, method=method,
                                 headers={"Content-Type": "application/json", "Authorization": AUTH})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.load(r)


def jmap(*calls):
    """Runs method calls in one request; returns their results, raising on any method error."""
    body = {"using": USING, "methodCalls": [[m, a, str(i)] for i, (m, a) in enumerate(calls)]}
    resp = http("POST", "/jmap", body)
    out = []
    for name, result, _ in resp["methodResponses"]:
        if name == "error":
            die(f"JMAP error: {json.dumps(result)}")
        out.append(result)
    return out


def check_set(result, what):
    for key in ("notCreated", "notUpdated", "notDestroyed"):
        if result.get(key):
            die(f"Stalwart rejected {what}: {json.dumps(result[key])}")


def as_set(values):
    """Stalwart's JSON form for a set: {"value": true, ...}."""
    return {v: True for v in values}


def as_list(values):
    """Stalwart's JSON form for an ordered list: {"0": ..., "1": ...}."""
    return {str(i): v for i, v in enumerate(values)}


def wait_for_server(timeout=180):
    deadline = time.time() + timeout
    last = ""
    while time.time() < deadline:
        try:
            http("GET", "/jmap/session", timeout=10)
            return
        except urllib.error.HTTPError as e:
            if e.code in (401, 403):
                die("Stalwart refused ADMIN_USER / ADMIN_PASSWORD. They must match .env as it was "
                    "when the stalwart container was (re)created — run `docker compose up -d` after editing .env.")
            last = f"HTTP {e.code}"
        except Exception as e:  # not listening yet
            last = str(e)
        time.sleep(2)
    die(f"Stalwart's admin API at {BASE} never answered ({last})")


# --------------------------------------------------------------------- bootstrap
def bootstrap_if_needed():
    (res,) = jmap(("x:Bootstrap/get", {"ids": ["singleton"]}))
    if not res.get("list"):
        return False  # already set up

    domain, hostname = env("MAIL_DOMAIN"), env("MAIL_HOSTNAME")
    token = env("CLOUDFLARE_API_TOKEN")
    log(f"First start: setting up {domain} (server name {hostname})")
    patch = {
        "defaultDomain": domain,
        "defaultHostname": hostname,
        "generateDkimKeys": True,
        "requestTlsCertificate": bool(token),
        "tracer": {"@type": "Stdout", "level": env("LOG_LEVEL", "info"), "ansi": False, "enable": True},
        "dnsServer": {"@type": "Manual"},
    }
    if token:
        patch["dnsServer"] = {
            "@type": "Cloudflare",
            "description": "Cloudflare",
            # The token stays in .env; Stalwart reads it from its environment.
            "secret": {"@type": "EnvironmentVariable", "variableName": "STALWART_CLOUDFLARE_TOKEN"},
        }
        log("Cloudflare token set: Stalwart will publish its DNS records and get a Let's Encrypt "
            "certificate via DNS-01")
    else:
        log("No CLOUDFLARE_API_TOKEN: add the DNS records yourself (the WebUI lists them for your domain) "
            "and set up a certificate in the WebUI")
    (res,) = jmap(("x:Bootstrap/set", {"update": {"singleton": patch}}))
    check_set(res, "the initial setup")
    log("Initial setup saved — Stalwart needs one restart to leave setup mode")
    return True


# --------------------------------------------------------------------- listeners
def desired_listeners():
    # A single address (Stalwart stores a /32 as the bare IP).
    trusted = as_set([env("FRPC_IP", "172.30.25.10")])
    want = {
        # Stalwart has no port-587 listener by default; mail apps on the LAN use it.
        "submission": {"bind": as_set(["[::]:587"]), "protocol": "smtp", "useTls": True,
                       "implicitTls": False, "overrideProxyTrustedNetworks": {}},
    }
    tunnels = [
        # name, .env switch (frps-side port), tunnel port var, default, protocol, implicit TLS
        ("smtp", "FRP_SMTP_REMOTE_PORT", "TUNNEL_SMTP_PORT", "10025", "smtp", False),
        ("submissions", "FRP_SUBMISSIONS_REMOTE_PORT", "TUNNEL_SUBMISSIONS_PORT", "10465", "smtp", True),
        ("submission", "FRP_SUBMISSION_REMOTE_PORT", "TUNNEL_SUBMISSION_PORT", "10587", "smtp", False),
        ("imaps", "FRP_IMAPS_REMOTE_PORT", "TUNNEL_IMAPS_PORT", "10993", "imap", True),
        ("sieve", "FRP_SIEVE_REMOTE_PORT", "TUNNEL_SIEVE_PORT", "14190", "manageSieve", False),
    ]
    for name, switch, port_var, default, proto, implicit in tunnels:
        if not env(switch):
            continue
        want[TUNNEL_PREFIX + name] = {
            "bind": as_set([f"[::]:{env(port_var, default)}"]),
            "protocol": proto, "useTls": True, "implicitTls": implicit,
            "overrideProxyTrustedNetworks": trusted,
        }
    return want


def reconcile_listeners():
    (res,) = jmap(("x:NetworkListener/get", {"ids": None}))
    have = {l["name"]: l for l in res["list"]}
    want = desired_listeners()
    create, update, destroy = {}, {}, []

    for name, fields in want.items():
        cur = have.get(name)
        if cur is None:
            create[name] = dict(fields, name=name)
            continue
        diff = {k: v for k, v in fields.items() if cur.get(k) != v}
        if diff:
            update[cur["id"]] = diff
    for name, cur in have.items():
        if name.startswith(TUNNEL_PREFIX) and name not in want:
            destroy.append(cur["id"])

    if not (create or update or destroy):
        return False
    (res,) = jmap(("x:NetworkListener/set", {"create": create, "update": update, "destroy": destroy}))
    check_set(res, "the listeners")
    for n in create:
        log(f"Listener added: {n}")
    for i in update:
        log(f"Listener updated: {next(n for n, l in have.items() if l['id'] == i)}")
    for i in destroy:
        log(f"Listener removed: {next(n for n, l in have.items() if l['id'] == i)}")
    return True


# --------------------------------------------------------------------- outgoing mail
def reconcile_relay():
    """Returns True if anything changed (applied with a settings reload)."""
    changed = False
    (routes,) = jmap(("x:MtaRoute/get", {"ids": None}))
    route = next((r for r in routes["list"] if r.get("name") == RELAY_ROUTE), None)
    enabled = env_bool("RELAY_ENABLED", "true")

    if enabled:
        for key in ("RELAY_HOST", "RELAY_USERNAME", "RELAY_PASSWORD"):
            if not env(key):
                die(f"RELAY_ENABLED=true but {key} is empty in .env")
        fields = {
            "host": env("RELAY_HOST"),
            "port": int(env("RELAY_PORT", "2465")),
            "protocol": "smtp",
            "implicitTls": True,
            # The relay uses a self-signed certificate on a port only Stalwart
            # logs in to, over your WireGuard tunnel.
            "allowInvalidCerts": True,
            "authUsername": env("RELAY_USERNAME"),
            "authSecret": {"@type": "EnvironmentVariable", "variableName": "STALWART_RELAY_PASSWORD"},
            "description": "mail-relay on the Linode (managed by .env)",
        }
        if route is None:
            (res,) = jmap(("x:MtaRoute/set", {"create": {"r": dict(fields, name=RELAY_ROUTE, **{"@type": "Relay"})}}))
            check_set(res, "the relay route")
            log(f"Relay route added: {fields['host']}:{fields['port']}")
            changed = True
        else:
            diff = {k: v for k, v in fields.items() if route.get(k) != v}
            if diff:
                (res,) = jmap(("x:MtaRoute/set", {"update": {route["id"]: diff}}))
                check_set(res, "the relay route")
                log(f"Relay route updated: {', '.join(diff)}")
                changed = True

    remote = f"'{RELAY_ROUTE}'" if enabled else "'mx'"
    want_route = {"match": as_list([{"if": "is_local_domain(rcpt_domain)", "then": "'local'"}]), "else": remote}
    (strategy,) = jmap(("x:MtaOutboundStrategy/get", {"ids": ["singleton"]}))
    if strategy["list"][0].get("route") != want_route:
        (res,) = jmap(("x:MtaOutboundStrategy/set", {"update": {"singleton": {"route": want_route}}}))
        check_set(res, "the outgoing route")
        log("Outgoing mail now goes " + (f"through the relay at {env('RELAY_HOST')}" if enabled
                                         else "directly to recipients' MX servers (RELAY_ENABLED=false)"))
        changed = True

    if not enabled and route is not None:
        log("RELAY_ENABLED=false: relay route kept but unused")
    return changed


def reconcile_log_level():
    level = env("LOG_LEVEL", "info")
    (res,) = jmap(("x:Tracer/get", {"ids": None}))
    upd = {t["id"]: {"level": level} for t in res["list"]
           if t.get("@type") == "Stdout" and t.get("level") != level}
    if not upd:
        return False
    (res,) = jmap(("x:Tracer/set", {"update": upd}))
    check_set(res, "the log level")
    log(f"Log level set to {level}")
    return True


def main():
    for key in ("ADMIN_PASSWORD", "MAIL_DOMAIN", "MAIL_HOSTNAME"):
        if not env(key):
            die(f"{key} is empty in .env")

    wait_for_server()
    if bootstrap_if_needed():
        sys.exit(RESTART_NEEDED)

    restart = reconcile_listeners()
    reload_needed = reconcile_relay()
    reload_needed = reconcile_log_level() or reload_needed

    if restart:
        log("Listener changes need a Stalwart restart to take effect")
        sys.exit(RESTART_NEEDED)
    if reload_needed:
        (res,) = jmap(("x:Action/set", {"create": {"a": {"@type": "ReloadSettings"}}}))
        check_set(res, "the settings reload")
        log("Settings reloaded")
    log("Stalwart matches .env")


if __name__ == "__main__":
    main()
